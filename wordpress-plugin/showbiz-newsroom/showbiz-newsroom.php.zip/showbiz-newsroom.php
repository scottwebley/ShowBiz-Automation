<?php
/**
 * Plugin Name: ShowBiz Newsroom
 * Plugin URI: https://showbiz.com
 * Description: Dynamic newsroom components for ShowBiz.com.
 * Version: 1.0.0
 * Author: ShowBiz Enterprises
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SHOWBIZ_NEWSROOM_VERSION', '1.0.0');
define('SHOWBIZ_NEWSROOM_PATH', plugin_dir_path(__FILE__));

require_once SHOWBIZ_NEWSROOM_PATH . 'includes/shortcode-winners.php';